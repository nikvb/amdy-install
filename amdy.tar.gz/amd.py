#!/usr/bin/python3 -O

"""
Fully Optimized Asterisk AGI Answering Machine Detection (AMD) Script
Python 3.4+ Compatible Version with Maximum Performance Optimizations
"""

import os
import fcntl
import time
import json
import select
from websocket import create_connection
from asterisk.agi import AGI

# Configuration Constants
AUDIO_FD = 3
WS_ENDPOINT = "ws://api.amdy.io:2700"
SAMPLE_RATE = 8000
SEND_TIMES = [0.7, 1.0, 2.0, 3.0]
MAX_WAIT_TIME = 5
SELECT_TIMEOUT = 0.05
FALLBACK_CHUNK_SIZE = 8000
MACHINE_DELAY = 0
NO_DATA_SLEEP = 0.1
CONNECTION_TIMEOUT = 10
AUDIO_READ_SIZE = 9500

def log_verbose(agi, message):
    agi.verbose("AMD: {}".format(message))

def set_amd_variables(agi, status, cause, stats=None):
    agi.set_variable('AMDSTATUS', status)
    agi.set_variable('AMDCAUSE', cause)
    if stats:
        agi.set_variable('AMDSTATS', stats)
    log_verbose(agi, "Variables set - Status: {}, Cause: {}".format(status, cause))

def create_websocket_connection(agi, caller_name):
    try:
        ws = create_connection(WS_ENDPOINT, timeout=CONNECTION_TIMEOUT)
        config = json.dumps({
            "config": {
                "sample_rate": SAMPLE_RATE,
                "VID": caller_name or "Unknown"
            }
        })
        ws.send(config)
        log_verbose(agi, "WebSocket connected to {}".format(WS_ENDPOINT))
        log_verbose(agi, "Config sent: sample_rate={}, VID={}".format(SAMPLE_RATE, caller_name))
        return ws
    except Exception as err:
        log_verbose(agi, "WebSocket connection failed: {}".format(err))
        log_verbose(agi, "AMD service unavailable - defaulting to HUMAN for safety")
        set_amd_variables(agi, "HUMAN", "CONNECTION_ERROR")
        return None

def cleanup_websocket(ws):
    try:
        if ws:
            ws.send(json.dumps({"eof": 1}))
            ws.close()
    except Exception:
        pass

def setup_audio_stream():
    fcntl.fcntl(AUDIO_FD, fcntl.F_SETFL, os.O_NONBLOCK)

def process_audio_chunk(agi, ws, audio_buffer):
    try:
        ws.send_binary(audio_buffer)
        log_verbose(agi, "Sent audio chunk: {} bytes".format(len(audio_buffer)))
        response = ws.recv()
        log_verbose(agi, "AMD response: {}".format(response))
        
        if 'HUMAN' in response:
            log_verbose(agi, "*** HUMAN DETECTED ***")
            set_amd_variables(agi, "HUMAN", "HUMAN", response)
            return True
        elif 'AMD' in response or 'MACHINE' in response:
            log_verbose(agi, "*** MACHINE DETECTED ***")
            set_amd_variables(agi, "MACHINE", response)
            log_verbose(agi, "Waiting {}s for machine to complete".format(MACHINE_DELAY))
            time.sleep(MACHINE_DELAY)
            return True
        return False
    except Exception as err:
        log_verbose(agi, "Audio processing error: {}".format(err))
        log_verbose(agi, "Network/processing error - defaulting to HUMAN")
        set_amd_variables(agi, "HUMAN", "PROCESSING_ERROR")
        return True

def process_audio_stream(agi, ws, channel):
    start_time = time.time()
    total_data_received = 0
    audio_buffer = b''
    send_index = 0
    
    log_verbose(agi, "Starting select()-optimized audio processing")
    log_verbose(agi, "Channel: {}".format(channel))
    log_verbose(agi, "Send schedule: {} seconds".format(SEND_TIMES))
    log_verbose(agi, "Process optimizations: select() I/O, time-based chunking")
    
    while True:
        current_time = time.time()
        elapsed_time = current_time - start_time
        
        try:
            if send_index < len(SEND_TIMES):
                time_until_next_send = SEND_TIMES[send_index] - elapsed_time
                select_timeout = max(0, min(time_until_next_send, SELECT_TIMEOUT))
            else:
                select_timeout = SELECT_TIMEOUT
            
            ready, _, _ = select.select([AUDIO_FD], [], [], select_timeout)
            
            if ready:
                try:
                    audio_chunk = os.read(AUDIO_FD, AUDIO_READ_SIZE)
                    if audio_chunk:
                        audio_buffer += audio_chunk
                    else:
                        log_verbose(agi, "End of audio stream detected")
                        log_verbose(agi, "Total data processed: {} bytes".format(total_data_received))
                        log_verbose(agi, "Channel [{}] HANGUP".format(channel))
                        set_amd_variables(agi, "HANGUP", "NO_AUDIO")
                        return
                except OSError as err:
                    if err.errno == 11:
                        log_verbose(agi, "Unexpected EAGAIN after select() - continuing")
                        continue
                    else:
                        raise
            
            if elapsed_time > MAX_WAIT_TIME:
                log_verbose(agi, "Global timeout reached after {}s".format(MAX_WAIT_TIME))
                log_verbose(agi, "Buffer: {} bytes, Total: {} bytes".format(len(audio_buffer), total_data_received))
                log_verbose(agi, "Channel [{}] TIMEOUT".format(channel))
                
                if total_data_received < 1:
                    set_amd_variables(agi, 'NOTSURE', 'NO_AUDIO_TIMEOUT')
                else:
                    set_amd_variables(agi, "HANGUP", "AUDIO_TIMEOUT")
                return
            
            if send_index < len(SEND_TIMES) and elapsed_time >= SEND_TIMES[send_index]:
                send_time = SEND_TIMES[send_index]
                
                if len(audio_buffer) > 0:
                    total_data_received += len(audio_buffer)
                    log_verbose(agi, "Time-based send #{}: threshold={}s, buffer={} bytes, total={} bytes, elapsed={:.3f}s".format(
                        send_index + 1, send_time, len(audio_buffer), total_data_received, elapsed_time))
                    
                    if process_audio_chunk(agi, ws, audio_buffer):
                        return
                    audio_buffer = b''
                else:
                    log_verbose(agi, "Time-based send #{}: threshold={}s, NO AUDIO DATA, elapsed={:.3f}s".format(
                        send_index + 1, send_time, elapsed_time))
                send_index += 1
            
            elif send_index >= len(SEND_TIMES) and len(audio_buffer) >= FALLBACK_CHUNK_SIZE:
                total_data_received += len(audio_buffer)
                log_verbose(agi, "Fallback size-based send: buffer={} bytes, total={} bytes, elapsed={:.3f}s".format(
                    len(audio_buffer), total_data_received, elapsed_time))
                
                if process_audio_chunk(agi, ws, audio_buffer):
                    return
                audio_buffer = b''
                
        except Exception as err:
            log_verbose(agi, "Unexpected error in audio processing: {}".format(err))
            log_verbose(agi, "Critical error - defaulting to HUMAN for safety")
            set_amd_variables(agi, "HUMAN", "PROCESSING_ERROR")
            return

def start_agi():
    agi = AGI()
    ws = None
    
    try:
        caller_id = agi.env.get('agi_callerid', 'Unknown')
        caller_name = agi.env.get('agi_calleridname', 'Unknown')
        extension = agi.env.get('agi_extension', 'Unknown')
        channel = agi.env.get('agi_channel', 'Unknown')
        
        log_verbose(agi, "=" * 50)
        log_verbose(agi, "AMD DETECTION STARTED")
        log_verbose(agi, "Caller ID: {} ({})".format(caller_id, caller_name))
        log_verbose(agi, "Extension: {}".format(extension))
        log_verbose(agi, "Channel: {}".format(channel))
        log_verbose(agi, "Optimizations: select() I/O, time-based chunking")
        log_verbose(agi, "=" * 50)
        
        ws = create_websocket_connection(agi, caller_name)
        if not ws:
            return
        
        setup_audio_stream()
        process_audio_stream(agi, ws, channel)
        
        log_verbose(agi, "=" * 50)
        log_verbose(agi, "AMD DETECTION COMPLETE")
        log_verbose(agi, "=" * 50)
        
    except Exception as err:
        log_verbose(agi, "FATAL ERROR in AMD processing: {}".format(err))
        log_verbose(agi, "Exception occurred - defaulting to HUMAN for call safety")
        set_amd_variables(agi, "HUMAN", "FATAL_ERROR")
        
    finally:
        cleanup_websocket(ws)

if __name__ == "__main__":
    start_agi()

